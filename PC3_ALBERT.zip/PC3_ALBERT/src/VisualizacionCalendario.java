/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */


import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.time.LocalDate;

/**
 * STRATEGY PATTERN: Visualización en formato de calendario
 */
public class VisualizacionCalendario implements EstrategiaVisualizacion {
    
    @Override
    public void mostrar(List<Tutoria> tutorias) {
        System.out.println("\n📅 VISTA DE CALENDARIO");
        System.out.println("=" .repeat(40));
        
        // Agrupar por fecha
        Map<LocalDate, List<Tutoria>> porFecha = tutorias.stream()
            .collect(Collectors.groupingBy(t -> t.getFechaHora().toLocalDate()));
        
        porFecha.forEach((fecha, tutoriasDelDia) -> {
            System.out.println("\n📆 " + fecha + " (" + tutoriasDelDia.size() + " tutorías)");
            System.out.println("-".repeat(30));
            
            tutoriasDelDia.forEach(t -> {
                System.out.printf("  🕐 %s - [%s] %s\n",
                    t.getFechaHora().toLocalTime(),
                    t.getEstado().getNombre(),
                    t.getMateria()
                );
                System.out.printf("      👨‍🎓 %s", t.getEstudiante().getNombre());
                if (t.getTutor() != null) {
                    System.out.printf(" | 👨‍🏫 %s", t.getTutor().getNombre());
                }
                System.out.println();
            });
        });
    }
    
    @Override
    public String getTipo() {
        return "CALENDARIO";
    }
}
