/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */


/**
 * OBSERVER PATTERN: Interfaz para observadores
 */
public interface Observer {
    void notificar(String mensaje, Tutoria tutoria);
}
