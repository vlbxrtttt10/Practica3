/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Clase principal que representa una tutoría
 * Implementa STATE PATTERN para manejar estados
 */
public class Tutoria {
    private String id;
    private Estudiante estudiante;
    private Tutor tutor;
    private String materia;
    private LocalDateTime fechaHora;
    private EstadoTutoria estado;
    
    public Tutoria(String id, Estudiante estudiante, String materia, LocalDateTime fechaHora) {
        this.id = id;
        this.estudiante = estudiante;
        this.materia = materia;
        this.fechaHora = fechaHora;
        this.estado = new EstadoSolicitada(); // Estado inicial
    }
    
    // STATE PATTERN: Delegar comportamiento al estado actual
    public void aceptar() {
        estado.aceptar(this);
    }
    
    public void rechazar() {
        estado.rechazar(this);
    }
    
    public void completar() {
        estado.completar(this);
    }
    
    public void cambiarEstado(EstadoTutoria nuevoEstado) {
        this.estado = nuevoEstado;
    }
    
    // Getters y setters
    public String getId() { return id; }
    public Estudiante getEstudiante() { return estudiante; }
    public Tutor getTutor() { return tutor; }
    public void setTutor(Tutor tutor) { this.tutor = tutor; }
    public String getMateria() { return materia; }
    public LocalDateTime getFechaHora() { return fechaHora; }
    public void setFechaHora(LocalDateTime fechaHora) { this.fechaHora = fechaHora; }
    public EstadoTutoria getEstado() { return estado; }
    
    public String getFechaFormateada() {
        return fechaHora.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
    }
}

