/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */

/**
 * STATE PATTERN: Estado cuando la tutoría es aceptada
 */
public class EstadoAceptada implements EstadoTutoria {
    
    @Override
    public void aceptar(Tutoria tutoria) {
        throw new IllegalStateException("La tutoría ya está aceptada");
    }
    
    @Override
    public void rechazar(Tutoria tutoria) {
        System.out.println("❌ Tutoría " + tutoria.getId() + " cancelada");
        tutoria.cambiarEstado(new EstadoRechazada());
    }
    
    @Override
    public void completar(Tutoria tutoria) {
        System.out.println("🎉 Tutoría " + tutoria.getId() + " completada");
        tutoria.cambiarEstado(new EstadoCompletada());
    }
    
    @Override
    public String getNombre() {
        return "ACEPTADA";
    }
}


