/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */


import java.util.List;

/**
 * STRATEGY PATTERN: Visualización en formato de lista
 */
public class VisualizacionLista implements EstrategiaVisualizacion {
    
    @Override
    public void mostrar(List<Tutoria> tutorias) {
        System.out.println("\n📋 VISTA DE LISTA");
        System.out.println("=" .repeat(40));
        
        for (int i = 0; i < tutorias.size(); i++) {
            Tutoria t = tutorias.get(i);
            System.out.printf("%d. [%s] %s - %s\n",
                i + 1,
                t.getEstado().getNombre(),
                t.getMateria(),
                t.getEstudiante().getNombre()
            );
            System.out.printf("   📅 %s\n", t.getFechaFormateada());
            if (t.getTutor() != null) {
                System.out.printf("   👨‍🏫 %s\n", t.getTutor().getNombre());
            }
            System.out.println();
        }
    }
    
    @Override
    public String getTipo() {
        return "LISTA";
    }
}

