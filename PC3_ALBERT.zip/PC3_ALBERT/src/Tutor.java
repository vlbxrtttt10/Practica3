/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 * Clase que representa a un tutor
 */
public class Tutor extends Usuario {
    private String especialidad;
    private boolean disponible;
    
    public Tutor(String id, String nombre, String email, String especialidad) {
        super(id, nombre, email);
        this.especialidad = especialidad;
        this.disponible = true;
    }
    
    @Override
    public boolean esAdministrador() {
        return false; // Los tutores no son administradores por defecto
    }
    
    public String getEspecialidad() { return especialidad; }
    public boolean isDisponible() { return disponible; }
    public void setDisponible(boolean disponible) { this.disponible = disponible; }
}

