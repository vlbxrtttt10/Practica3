/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */


/**
 * Clase que representa a un administrador del sistema
 */
public class Administrador extends Usuario {
    
    public Administrador(String id, String nombre, String email) {
        super(id, nombre, email);
    }
    
    @Override
    public boolean esAdministrador() {
        return true; // Los administradores tienen permisos completos
    }
}

