/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */

/**
 * STATE PATTERN: Estado final cuando la tutoría es rechazada
 */
public class EstadoRechazada implements EstadoTutoria {
    
    @Override
    public void aceptar(Tutoria tutoria) {
        throw new IllegalStateException("No se puede aceptar una tutoría rechazada");
    }
    
    @Override
    public void rechazar(Tutoria tutoria) {
        throw new IllegalStateException("La tutoría ya está rechazada");
    }
    
    @Override
    public void completar(Tutoria tutoria) {
        throw new IllegalStateException("No se puede completar una tutoría rechazada");
    }
    
    @Override
    public String getNombre() {
        return "RECHAZADA";
    }
}

