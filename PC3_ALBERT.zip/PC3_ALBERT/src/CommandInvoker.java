/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */

import java.util.Stack;

/**
 * COMMAND PATTERN: Invoker que ejecuta comandos y mantiene historial
 */
public class CommandInvoker {
    private Stack<Command> historial;
    
    public CommandInvoker() {
        this.historial = new Stack<>();
    }
    
    public void ejecutarComando(Command comando) {
        comando.ejecutar();
        historial.push(comando);
        System.out.println("📝 Comando ejecutado: " + comando.getDescripcion());
    }
    
    public void deshacerUltimoComando() {
        if (!historial.isEmpty()) {
            Command ultimoComando = historial.pop();
            ultimoComando.deshacer();
            System.out.println("↩️ Comando deshecho: " + ultimoComando.getDescripcion());
        } else {
            System.out.println("❌ No hay comandos para deshacer");
        }
    }
    
    public void mostrarHistorial() {
        System.out.println("\n📋 Historial de comandos:");
        for (int i = historial.size() - 1; i >= 0; i--) {
            System.out.println((historial.size() - i) + ". " + historial.get(i).getDescripcion());
        }
    }
}
