/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */


/**
 * STATE PATTERN: Estado final cuando la tutoría es completada
 */
public class EstadoCompletada implements EstadoTutoria {
    
    @Override
    public void aceptar(Tutoria tutoria) {
        throw new IllegalStateException("No se puede aceptar una tutoría completada");
    }
    
    @Override
    public void rechazar(Tutoria tutoria) {
        throw new IllegalStateException("No se puede rechazar una tutoría completada");
    }
    
    @Override
    public void completar(Tutoria tutoria) {
        throw new IllegalStateException("La tutoría ya está completada");
    }
    
    @Override
    public String getNombre() {
        return "COMPLETADA";
    }
}

