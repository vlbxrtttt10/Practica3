/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */

/**
 * COMMAND PATTERN: Comando para asignar tutor
 */
public class AsignarTutorCommand implements Command {
    private Tutoria tutoria;
    private Tutor tutor;
    private Tutor tutorAnterior;
    private SistemaNotificaciones notificaciones;
    
    public AsignarTutorCommand(Tutoria tutoria, Tutor tutor, SistemaNotificaciones notificaciones) {
        this.tutoria = tutoria;
        this.tutor = tutor;
        this.tutorAnterior = tutoria.getTutor();
        this.notificaciones = notificaciones;
    }
    
    @Override
    public void ejecutar() {
        String estadoAnterior = tutoria.getEstado().getNombre();
        tutoria.setTutor(tutor);
        tutoria.aceptar();
        
        System.out.println("✅ Tutor " + tutor.getNombre() + " asignado a tutoría " + tutoria.getId());
        notificaciones.notificarCambioEstado(tutoria, estadoAnterior);
    }
    
    @Override
    public void deshacer() {
        tutoria.setTutor(tutorAnterior);
        System.out.println("↩️ Asignación deshecha para tutoría " + tutoria.getId());
    }
    
    @Override
    public String getDescripcion() {
        return "Asignar tutor " + tutor.getNombre() + " a tutoría " + tutoria.getId();
    }
}
