/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */

/**
 * OBSERVER PATTERN: Observador concreto para notificar usuarios
 */
public class NotificadorUsuario implements Observer {
    private Usuario usuario;
    
    public NotificadorUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    @Override
    public void notificar(String mensaje, Tutoria tutoria) {
        // Solo notificar si el usuario está involucrado en la tutoría
        if (estaInvolucrado(tutoria)) {
            System.out.println("📧 Notificación para " + usuario.getNombre() + ": " + mensaje);
        }
    }
    
    private boolean estaInvolucrado(Tutoria tutoria) {
        return tutoria.getEstudiante().getId().equals(usuario.getId()) ||
               (tutoria.getTutor() != null && tutoria.getTutor().getId().equals(usuario.getId()));
    }
}

