/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */


/**
 * STATE PATTERN: Estado inicial de una tutoría
 */
public class EstadoSolicitada implements EstadoTutoria {
    
    @Override
    public void aceptar(Tutoria tutoria) {
        System.out.println("✅ Tutoría " + tutoria.getId() + " aceptada");
        tutoria.cambiarEstado(new EstadoAceptada());
    }
    
    @Override
    public void rechazar(Tutoria tutoria) {
        System.out.println("❌ Tutoría " + tutoria.getId() + " rechazada");
        tutoria.cambiarEstado(new EstadoRechazada());
    }
    
    @Override
    public void completar(Tutoria tutoria) {
        throw new IllegalStateException("No se puede completar una tutoría solicitada");
    }
    
    @Override
    public String getNombre() {
        return "SOLICITADA";
    }
}
