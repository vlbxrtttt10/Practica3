/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */
/**
 * Clase que representa a un estudiante
 */
public class Estudiante extends Usuario {
    private String carrera;
    
    public Estudiante(String id, String nombre, String email, String carrera) {
        super(id, nombre, email);
        this.carrera = carrera;
    }
    
    @Override
    public boolean esAdministrador() {
        return false; // Los estudiantes no son administradores
    }
    
    public String getCarrera() { return carrera; }
}

