/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */

/**
 * PROXY PATTERN: Controla acceso a operaciones administrativas
 */
public class ProxyAdministrativo {
    private CommandInvoker invoker;
    private Usuario usuario;
    
    public ProxyAdministrativo(CommandInvoker invoker, Usuario usuario) {
        this.invoker = invoker;
        this.usuario = usuario;
    }
    
    public void ejecutarComando(Command comando) {
        if (usuario.esAdministrador()) {
            System.out.println("🔐 Acceso autorizado para " + usuario.getNombre());
            invoker.ejecutarComando(comando);
        } else {
            System.out.println("🚫 Acceso denegado. " + usuario.getNombre() + " no es administrador");
        }
    }
    
    public void deshacer() {
        if (usuario.esAdministrador()) {
            invoker.deshacerUltimoComando();
        } else {
            System.out.println("🚫 Acceso denegado para deshacer comandos");
        }
    }
}
