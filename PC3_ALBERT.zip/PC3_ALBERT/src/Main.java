/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Clase principal INTERACTIVA del sistema
 * PATRONES IMPLEMENTADOS:
 * - STATE: Estados de tutorías
 * - OBSERVER: Notificaciones automáticas  
 * - COMMAND: Comandos con undo
 * - PROXY: Control de acceso
 * - STRATEGY: Visualizaciones intercambiables
 */
public class Main {
    
    private static Scanner scanner = new Scanner(System.in);
    private static List<Usuario> usuarios = new ArrayList<>();
    private static List<Tutoria> tutorias = new ArrayList<>();
    private static SistemaNotificaciones notificaciones = new SistemaNotificaciones();
    private static CommandInvoker invoker = new CommandInvoker();
    private static VisualizadorTutorias visualizador = new VisualizadorTutorias(new VisualizacionLista());
    private static Usuario usuarioActual = null;
    
    public static void main(String[] args) {
        mostrarBanner();
        inicializarDatos();
        
        while (true) {
            mostrarMenuPrincipal();
            int opcion = leerOpcion();
            
            switch (opcion) {
                case 1: menuUsuarios(); break;
                case 2: menuTutorias(); break;
                case 3: menuComandos(); break;
                case 4: menuVisualizacion(); break;
                case 5: verNotificaciones(); break;
                case 6: cambiarUsuario(); break;
                case 0: 
                    System.out.println("👋 ¡Gracias por usar el Sistema de Tutorías UTP!");
                    return;
                default:
                    System.out.println("❌ Opción inválida");
            }
        }
    }
    
    private static void mostrarBanner() {
        System.out.println("╔" + "═".repeat(50) + "╗");
        System.out.println("║" + centrar("🎓 SISTEMA DE TUTORÍAS UTP", 50) + "║");
        System.out.println("║" + centrar("Versión Interactiva", 50) + "║");
        System.out.println("╚" + "═".repeat(50) + "╝");
        System.out.println();
    }
    
    private static String centrar(String texto, int ancho) {
        int espacios = (ancho - texto.length()) / 2;
        return " ".repeat(espacios) + texto + " ".repeat(ancho - texto.length() - espacios);
    }
    
    private static void inicializarDatos() {
        // Crear algunos usuarios por defecto
        Estudiante est1 = new Estudiante("E001", "Ana García", "ana@utp.edu.pe", "Ing. Sistemas");
        Tutor tut1 = new Tutor("T001", "Dr. María López", "maria@utp.edu.pe", "Java");
        Administrador admin = new Administrador("A001", "Admin Sistema", "admin@utp.edu.pe");
        
        usuarios.add(est1);
        usuarios.add(tut1);
        usuarios.add(admin);
        
        // Configurar notificaciones
        for (Usuario usuario : usuarios) {
            notificaciones.agregarObservador(new NotificadorUsuario(usuario));
        }
        
        usuarioActual = admin; // Usuario por defecto
        System.out.println("✅ Sistema inicializado con datos de prueba");
        System.out.println("👤 Usuario actual: " + usuarioActual.getNombre());
    }
    
    private static void mostrarMenuPrincipal() {
        System.out.println("\n" + "═".repeat(40));
        System.out.println("📋 MENÚ PRINCIPAL");
        System.out.println("Usuario actual: " + usuarioActual.getNombre() + 
                          (usuarioActual.esAdministrador() ? " (Admin)" : ""));
        System.out.println("═".repeat(40));
        System.out.println("1. 👥 Gestión de Usuarios");
        System.out.println("2. 📚 Gestión de Tutorías");
        System.out.println("3. ⚙️ Comandos Administrativos");
        System.out.println("4. 🎨 Visualización de Tutorías");
        System.out.println("5. 📢 Ver Notificaciones");
        System.out.println("6. 🔄 Cambiar Usuario");
        System.out.println("0. 🚪 Salir");
        System.out.print("Seleccione una opción: ");
    }
    
    private static void menuUsuarios() {
        while (true) {
            System.out.println("\n👥 GESTIÓN DE USUARIOS");
            System.out.println("1. Registrar Estudiante");
            System.out.println("2. Registrar Tutor");
            System.out.println("3. Registrar Administrador");
            System.out.println("4. Listar Usuarios");
            System.out.println("0. Volver");
            System.out.print("Opción: ");
            
            int opcion = leerOpcion();
            switch (opcion) {
                case 1: registrarEstudiante(); break;
                case 2: registrarTutor(); break;
                case 3: registrarAdministrador(); break;
                case 4: listarUsuarios(); break;
                case 0: return;
                default: System.out.println("❌ Opción inválida");
            }
        }
    }
    
    private static void registrarEstudiante() {
        System.out.println("\n📝 REGISTRAR ESTUDIANTE");
        System.out.print("ID: ");
        String id = scanner.nextLine();
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Carrera: ");
        String carrera = scanner.nextLine();
        
        Estudiante estudiante = new Estudiante(id, nombre, email, carrera);
        usuarios.add(estudiante);
        notificaciones.agregarObservador(new NotificadorUsuario(estudiante));
        
        System.out.println("✅ Estudiante registrado: " + estudiante.getNombre());
    }
    
    private static void registrarTutor() {
        System.out.println("\n📝 REGISTRAR TUTOR");
        System.out.print("ID: ");
        String id = scanner.nextLine();
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Especialidad: ");
        String especialidad = scanner.nextLine();
        
        Tutor tutor = new Tutor(id, nombre, email, especialidad);
        usuarios.add(tutor);
        notificaciones.agregarObservador(new NotificadorUsuario(tutor));
        
        System.out.println("✅ Tutor registrado: " + tutor.getNombre());
    }
    
    private static void registrarAdministrador() {
        if (!usuarioActual.esAdministrador()) {
            System.out.println("🚫 Solo los administradores pueden registrar otros administradores");
            return;
        }
        
        System.out.println("\n📝 REGISTRAR ADMINISTRADOR");
        System.out.print("ID: ");
        String id = scanner.nextLine();
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        
        Administrador admin = new Administrador(id, nombre, email);
        usuarios.add(admin);
        notificaciones.agregarObservador(new NotificadorUsuario(admin));
        
        System.out.println("✅ Administrador registrado: " + admin.getNombre());
    }
    
    private static void listarUsuarios() {
        System.out.println("\n👥 LISTA DE USUARIOS");
        System.out.println("═".repeat(60));
        
        for (Usuario usuario : usuarios) {
            String tipo = usuario.getClass().getSimpleName();
            String admin = usuario.esAdministrador() ? " (Admin)" : "";
            System.out.printf("%-10s %-20s %-25s %s%s\n", 
                            usuario.getId(), 
                            tipo, 
                            usuario.getNombre(), 
                            usuario.getEmail(),
                            admin);
        }
    }
    
    private static void menuTutorias() {
        while (true) {
            System.out.println("\n📚 GESTIÓN DE TUTORÍAS");
            System.out.println("1. Crear Tutoría");
            System.out.println("2. Listar Tutorías");
            System.out.println("3. Cambiar Estado de Tutoría");
            System.out.println("0. Volver");
            System.out.print("Opción: ");
            
            int opcion = leerOpcion();
            switch (opcion) {
                case 1: crearTutoria(); break;
                case 2: listarTutorias(); break;
                case 3: cambiarEstadoTutoria(); break;
                case 0: return;
                default: System.out.println("❌ Opción inválida");
            }
        }
    }
    
    private static void crearTutoria() {
        System.out.println("\n📝 CREAR TUTORÍA");
        
        // Mostrar estudiantes disponibles
        System.out.println("Estudiantes disponibles:");
        List<Estudiante> estudiantes = new ArrayList<>();
        for (Usuario u : usuarios) {
            if (u instanceof Estudiante) {
                estudiantes.add((Estudiante) u);
                System.out.println((estudiantes.size()) + ". " + u.getNombre());
            }
        }
        
        if (estudiantes.isEmpty()) {
            System.out.println("❌ No hay estudiantes registrados");
            return;
        }
        
        System.out.print("Seleccione estudiante (número): ");
        int indiceEst = leerOpcion() - 1;
        if (indiceEst < 0 || indiceEst >= estudiantes.size()) {
            System.out.println("❌ Estudiante inválido");
            return;
        }
        
        System.out.print("ID de la tutoría: ");
        String id = scanner.nextLine();
        System.out.print("Materia: ");
        String materia = scanner.nextLine();
        System.out.print("Días a futuro (número): ");
        int dias = leerOpcion();
        
        Tutoria tutoria = new Tutoria(id, estudiantes.get(indiceEst), materia, 
                                     LocalDateTime.now().plusDays(dias));
        tutorias.add(tutoria);
        
        System.out.println("✅ Tutoría creada: " + tutoria.getId());
        System.out.println("Estado inicial: " + tutoria.getEstado().getNombre());
    }
    
    private static void listarTutorias() {
        if (tutorias.isEmpty()) {
            System.out.println("📭 No hay tutorías registradas");
            return;
        }
        
        visualizador.mostrarTutorias(tutorias);
    }
    
    private static void cambiarEstadoTutoria() {
        if (tutorias.isEmpty()) {
            System.out.println("📭 No hay tutorías registradas");
            return;
        }
        
        System.out.println("\n🔄 CAMBIAR ESTADO DE TUTORÍA");
        System.out.println("Tutorías disponibles:");
        for (int i = 0; i < tutorias.size(); i++) {
            Tutoria t = tutorias.get(i);
            System.out.printf("%d. %s - %s (%s)\n", 
                            i + 1, t.getId(), t.getMateria(), t.getEstado().getNombre());
        }
        
        System.out.print("Seleccione tutoría (número): ");
        int indice = leerOpcion() - 1;
        if (indice < 0 || indice >= tutorias.size()) {
            System.out.println("❌ Tutoría inválida");
            return;
        }
        
        Tutoria tutoria = tutorias.get(indice);
        System.out.println("Estado actual: " + tutoria.getEstado().getNombre());
        System.out.println("1. Aceptar");
        System.out.println("2. Rechazar");
        System.out.println("3. Completar");
        System.out.print("Acción: ");
        
        int accion = leerOpcion();
        String estadoAnterior = tutoria.getEstado().getNombre();
        
        try {
            switch (accion) {
                case 1:
                    tutoria.aceptar();
                    notificaciones.notificarCambioEstado(tutoria, estadoAnterior);
                    break;
                case 2:
                    tutoria.rechazar();
                    notificaciones.notificarCambioEstado(tutoria, estadoAnterior);
                    break;
                case 3:
                    tutoria.completar();
                    notificaciones.notificarCambioEstado(tutoria, estadoAnterior);
                    break;
                default:
                    System.out.println("❌ Acción inválida");
                    return;
            }
            System.out.println("✅ Estado cambiado a: " + tutoria.getEstado().getNombre());
        } catch (IllegalStateException e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }
    
    private static void menuComandos() {
        while (true) {
            System.out.println("\n⚙️ COMANDOS ADMINISTRATIVOS");
            System.out.println("1. Asignar Tutor");
            System.out.println("2. Ver Historial de Comandos");
            System.out.println("3. Deshacer Último Comando");
            System.out.println("0. Volver");
            System.out.print("Opción: ");
            
            int opcion = leerOpcion();
            switch (opcion) {
                case 1: asignarTutor(); break;
                case 2: invoker.mostrarHistorial(); break;
                case 3: deshacerComando(); break;
                case 0: return;
                default: System.out.println("❌ Opción inválida");
            }
        }
    }
    
    private static void asignarTutor() {
        if (tutorias.isEmpty()) {
            System.out.println("📭 No hay tutorías registradas");
            return;
        }
        
        // PROXY PATTERN: Control de acceso
        ProxyAdministrativo proxy = new ProxyAdministrativo(invoker, usuarioActual);
        
        System.out.println("\n👨‍🏫 ASIGNAR TUTOR");
        
        // Mostrar tutorías
        System.out.println("Tutorías disponibles:");
        for (int i = 0; i < tutorias.size(); i++) {
            Tutoria t = tutorias.get(i);
            System.out.printf("%d. %s - %s (%s)\n", 
                            i + 1, t.getId(), t.getMateria(), t.getEstado().getNombre());
        }
        
        System.out.print("Seleccione tutoría (número): ");
        int indiceTut = leerOpcion() - 1;
        if (indiceTut < 0 || indiceTut >= tutorias.size()) {
            System.out.println("❌ Tutoría inválida");
            return;
        }
        
        // Mostrar tutores
        System.out.println("Tutores disponibles:");
        List<Tutor> tutores = new ArrayList<>();
        for (Usuario u : usuarios) {
            if (u instanceof Tutor) {
                tutores.add((Tutor) u);
                System.out.println(tutores.size() + ". " + u.getNombre() + 
                                 " (" + ((Tutor) u).getEspecialidad() + ")");
            }
        }
        
        if (tutores.isEmpty()) {
            System.out.println("❌ No hay tutores registrados");
            return;
        }
        
        System.out.print("Seleccione tutor (número): ");
        int indiceTutor = leerOpcion() - 1;
        if (indiceTutor < 0 || indiceTutor >= tutores.size()) {
            System.out.println("❌ Tutor inválido");
            return;
        }
        
        // COMMAND PATTERN: Crear y ejecutar comando
        Command comando = new AsignarTutorCommand(tutorias.get(indiceTut), 
                                                 tutores.get(indiceTutor), 
                                                 notificaciones);
        proxy.ejecutarComando(comando);
    }
    
    private static void deshacerComando() {
        ProxyAdministrativo proxy = new ProxyAdministrativo(invoker, usuarioActual);
        proxy.deshacer();
    }
    
    private static void menuVisualizacion() {
        while (true) {
            System.out.println("\n🎨 VISUALIZACIÓN DE TUTORÍAS");
            System.out.println("Vista actual: " + visualizador.getTipo());
            System.out.println("1. Vista de Lista");
            System.out.println("2. Vista de Calendario");
            System.out.println("3. Mostrar Tutorías");
            System.out.println("0. Volver");
            System.out.print("Opción: ");
            
            int opcion = leerOpcion();
            switch (opcion) {
                case 1:
                    // STRATEGY PATTERN: Cambiar estrategia
                    visualizador.cambiarEstrategia(new VisualizacionLista());
                    break;
                case 2:
                    visualizador.cambiarEstrategia(new VisualizacionCalendario());
                    break;
                case 3:
                    if (tutorias.isEmpty()) {
                        System.out.println("📭 No hay tutorías para mostrar");
                    } else {
                        visualizador.mostrarTutorias(tutorias);
                    }
                    break;
                case 0: return;
                default: System.out.println("❌ Opción inválida");
            }
        }
    }
    
    private static void verNotificaciones() {
        System.out.println("\n📢 SISTEMA DE NOTIFICACIONES");
        System.out.println("Las notificaciones se muestran automáticamente cuando:");
        System.out.println("• Se cambia el estado de una tutoría");
        System.out.println("• Se asigna un tutor");
        System.out.println("• Se ejecutan comandos administrativos");
        System.out.println("\n💡 Las notificaciones aparecen en tiempo real durante el uso del sistema");
    }
    
    private static void cambiarUsuario() {
        System.out.println("\n🔄 CAMBIAR USUARIO");
        System.out.println("Usuarios disponibles:");
        
        for (int i = 0; i < usuarios.size(); i++) {
            Usuario u = usuarios.get(i);
            String tipo = u.getClass().getSimpleName();
            String admin = u.esAdministrador() ? " (Admin)" : "";
            System.out.printf("%d. %s - %s%s\n", i + 1, u.getNombre(), tipo, admin);
        }
        
        System.out.print("Seleccione usuario (número): ");
        int indice = leerOpcion() - 1;
        if (indice >= 0 && indice < usuarios.size()) {
            usuarioActual = usuarios.get(indice);
            System.out.println("✅ Usuario cambiado a: " + usuarioActual.getNombre());
        } else {
            System.out.println("❌ Usuario inválido");
        }
    }
    
    private static int leerOpcion() {
        try {
            String input = scanner.nextLine().trim();
            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
