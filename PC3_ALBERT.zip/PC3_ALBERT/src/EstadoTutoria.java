/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */

/**
 * STATE PATTERN: Interfaz para los estados de una tutoría
 */
public interface EstadoTutoria {
    void aceptar(Tutoria tutoria);
    void rechazar(Tutoria tutoria);
    void completar(Tutoria tutoria);
    String getNombre();
}

