/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */

import java.util.ArrayList;
import java.util.List;

/**
 * OBSERVER PATTERN: Subject que maneja las notificaciones
 */
public class SistemaNotificaciones {
    private List<Observer> observadores;
    
    public SistemaNotificaciones() {
        this.observadores = new ArrayList<>();
    }
    
    public void agregarObservador(Observer observador) {
        observadores.add(observador);
    }
    
    public void notificarCambioEstado(Tutoria tutoria, String estadoAnterior) {
        String mensaje = "Tutoría " + tutoria.getId() + " cambió de " + 
                        estadoAnterior + " a " + tutoria.getEstado().getNombre();
        
        for (Observer observador : observadores) {
            observador.notificar(mensaje, tutoria);
        }
    }
}
