/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */


import java.util.List;

/**
 * STRATEGY PATTERN: Interfaz para estrategias de visualización
 */
public interface EstrategiaVisualizacion {
    void mostrar(List<Tutoria> tutorias);
    String getTipo();
}
