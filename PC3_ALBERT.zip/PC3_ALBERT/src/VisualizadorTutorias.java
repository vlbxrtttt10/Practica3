/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LAB-USR-ATE
 */

import java.util.List;

/**
 * STRATEGY PATTERN: Contexto que usa las estrategias
 */
public class VisualizadorTutorias {
    private EstrategiaVisualizacion estrategia;
    
    public VisualizadorTutorias(EstrategiaVisualizacion estrategia) {
        this.estrategia = estrategia;
    }
    
    public void cambiarEstrategia(EstrategiaVisualizacion nuevaEstrategia) {
        this.estrategia = nuevaEstrategia;
        System.out.println("🔄 Cambiando a vista: " + nuevaEstrategia.getTipo());
    }
    
    public void mostrarTutorias(List<Tutoria> tutorias) {
        estrategia.mostrar(tutorias);
    }
}
